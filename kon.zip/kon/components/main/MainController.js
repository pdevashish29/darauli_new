var MainController =  ['$scope','$rootScope','$state','$sessionStorage', '$firebaseAuth',function($scope, $rootScope, $state, $sessionStorage,$firebaseAuth) {
	$scope.spinner=false;
	$scope.defaultUserImage="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTz-_3M-pHdWyfIr__MPZOSsKPq1hBAUhdwl4MMkSKmtcEJRk0g";
	$scope.logoImageUrl="https://firebasestorage.googleapis.com/v0/b/vflip-83ae2.appspot.com/o/vflipLogo.png?alt=media&token=6d407cf4-56f0-4348-a475-ff6ca18ee571";
	var db =firebase.database();
	$scope.authObj = $firebaseAuth();
	$scope.$storage = $sessionStorage;
	
	$scope.getSession = function() {
		return $scope.$storage.session;
	};
	$rootScope.$state = $state;
	$rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
		var requireLogin = toState.data.requireLogin;
		if (requireLogin && $scope.getSession() == null) {
			event.preventDefault();
			$state.go('login');
		}
	});
	
	$scope.handleLoginNew= function(){
		$scope.spinner=true;
		$scope.errorMessage="";
	if($scope.userName!=undefined && $scope.password !=undefined ){
		$scope.authObj.$signInWithEmailAndPassword($scope.userName, $scope.password).then(function(firebaseUser) {
			if(!firebaseUser.emailVerified){
				 $scope.errMessage="Please verify your email";
				 $scope.spinner=false;
			}else{
			  //console.log("Signed in as:", firebaseUser.uid);
			  ///console.log(firebaseUser);
			    var  email= firebaseUser.email.replace(/[.*+?^${}()|[\]\\]/g, "\,");//
			   // console.log(firebaseUser.email.replace(/[.*+?^${}()|[\]\\]/g, "\,")); 
			  // handle Routing on success 
			  // step 1 --- update User is online-- a) online, offline, onCall
			  	 db.ref("userDetails/"+email).update({status: 'online'}).then(function(){
					  console.log("user status is changed to online handleLogin -mainController");
				  });	
			  
				 db.ref('/userDetails/' +email).once('value').then(function(snapshot) {
					 	$scope.$storage.session = {user:snapshot.val(), email:email};
					 	$scope.spinner=false;
				  	 	$state.go('chat');
				}); 
			}
			}).catch(function(error) {
					$scope.spinner=false;
					console.error("Authentication failed:", error);
					var errorCode = error.code;
				if (errorCode === 'auth/wrong-password') {
			        	$scope.errMessage="Wrong password";
			        	$scope.password='';
		        }else if(errorCode == 'auth/invalid-email'){
			        	$scope.errMessage="Invalid email";
			        	$scope.userName='';
			        	$scope.password='';
		        }else if(errorCode=='auth/user-not-found'){
			        	$scope.errMessage="User not found";
			        	$scope.userName='';
			        	$scope.password='';
		        }
			});	
		} else{
				$scope.spinner=false;
				$scope.errMessage="Missing input ";
		}
	}// end of handleLogin new
	
	$scope.handleSignUp=function(user){
		$scope.spinner=true;
		$scope.errMessage='';
			if(user!=undefined && user.firstName!=undefined && user.lastName!=undefined && user.email != undefined && user.password!=undefined){
				firebase.auth().createUserWithEmailAndPassword(user.email, user.password).then(function(){
					console.log("user is creeated ...");
					var tempUser = firebase.auth().currentUser;
					tempUser.sendEmailVerification().then(function() {
						console.log("email is sent");
						  var  refinedEmail= user.email.replace(/[.*+?^${}()|[\]\\]/g, "\,");//
						  var uniqueId=$scope.getUniqueNumber();
						 db.ref("userDetails/"+refinedEmail).set({
							  address:'',
							  aliasName:user.firstName ,
						      displayName: user.firstName +' ' +user.lastName,
							  imageUrl: $scope.defaultUserImage,
							  phoneNumber: '',
							  privacy:'public',
							  sex:'',
							  status:'offline',
							  uniqueId: uniqueId
						 }).then(function(){
							 db.ref("emailIds/"+refinedEmail).set({
								  aliasName:user.firstName ,
								  imageUrl: $scope.defaultUserImage,
								  privacy:'public',
								  uniqueId: uniqueId
							 });
							  console.log("user default data is inserted ");
							  $scope.$apply(function(){
								  $scope.successMessage="Please verify your email address to further secure your vFLIP Online account. "
								  $scope.user=undefined;	  
								  $scope.spinner=false;
							  });
								$('#successSignUpModal').modal({show:true,backdrop:'static'}); //  opend here 
							  
						  });	
					}, function(error) {
						$scope.spinner=false;
						console.log(error+"location 1");
					});
				}).catch(function(error) {
					$scope.spinner=false;
					console.log(error+"location 2");
					if(error.code =='auth/invalid-email'){
						$scope.$apply(function(){
							$scope.errMessage="Invalid email";
						});
						
					}else if(error.code =='auth/weak-password'){
					$scope.$apply(function(){
						$scope.errMessage=error.message;
					});
						
					}else if(error.code =="auth/email-already-in-use"){
						$scope.$apply(function(){
							$scope.errMessage="email is already in use by another account";
						});
					}else {
						$scope.$apply(function(){
							$scope.errMessage=error;
						});
					}
					
				}); //end of catch 
				
			}else{
				// 
				$scope.spinner=false;
				console.log("Missing input");
				$scope.errMessage="Missing input ";
			}
	}
	$scope.getUniqueNumber= function(){
		var uniqueId =new Chance().natural({min:100000,max:999999});
		//console.log(uniqueId);
		return uniqueId+"";
	}
	
	$scope.goHome = function() {
		if ($scope.getSession() == null) {
			$state.go('login');
		} else {
			$state.go('dashboard');
		}
	}
	$scope.forgetPassword= function(){
		$scope.spinner=true;
		if($scope.forgetUserEmail!=undefined){
			var emailOfUser=$scope.forgetUserEmail;
			firebase.auth().sendPasswordResetEmail(emailOfUser).then(function() {
				  // Email sent.
				$scope.forgetUserEmail=undefined;
				$scope.$apply(function(){
					$scope.spinner=false;
					$scope.errMessage="Password reset link sent to your mail, Check your inbox. ";
				});
				}, function(error) {
					console.log(error);
					$scope.spinner=false;
					$scope.forgetUserEmail=undefined;
				  // An error happened.
					
					if(error.code=='auth/invalid-email'){
						$scope.$apply(function(){
							$scope.errMessage ="Invalid email";
						});
						
					}else if(error.code=='auth/user-not-found'){
						$scope.$apply(function(){
							$scope.errMessage = "User not found";
						});
					}
					
				});
		}else{
			 $scope.spinner=false;
			 $scope.errMessage="Missing Input";
		}
	}
	
	$scope.goTo= function(whereTo){
		$state.go(whereTo);
	}
}];

