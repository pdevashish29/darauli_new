
  var config = {
    apiKey: "AIzaSyDxbGO5xPxe0iyIBamcxeBqGQDXR44nZxQ",
    authDomain: "vflip-1355c.firebaseapp.com",
    databaseURL: "https://vflip-1355c.firebaseio.com",
    storageBucket: "vflip-1355c.appspot.com",
    messagingSenderId: "830768352614"
  };
  firebase.initializeApp(config);
	
var app = angular.module('chatApp', ['firebase','ui.router','ui.router.stateHelper','ngCookies','ngResource','ngStorage','ui.bootstrap']);

app.config(['stateHelperProvider','$urlRouterProvider','$urlMatcherFactoryProvider',function(stateHelperProvider,$urlRouterProvider,$urlMatcherFactoryProvider) {
	$urlRouterProvider.otherwise("/login");
	$urlMatcherFactoryProvider.strictMode(false)
	stateHelperProvider
	.state({
		name: "login",
		url: "/login",
		templateUrl: "components/login.html",
		controller: "MainController",
		data: { requireLogin : false }
	}).state({
		name: "signUp",
		url: "/signUp",
		templateUrl: "components/signUp.html",
		controller: "MainController",
		data: { requireLogin : false }
	}).state({
		name: "forget",
		url: "/forget",
		templateUrl: "components/forget.html",
		controller: "MainController",
		data: { requireLogin : false }
	}).state({
		name: "chat",
		url: "/chat",
		templateUrl: "components/dashboard/chat.html",
		controller: "chatController",
		data: { requireLogin : true }
	});

}]);




/** Controllers **/
app.controller('MainController', MainController);
app.controller('chatController',chatController);



 

